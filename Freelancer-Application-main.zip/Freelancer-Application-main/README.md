Thrive 

A Freelancing  Platform


Welcome to Thrive, a freelancer application where freelancers, clients, and admins interact to manage projects effectively.

DEMO LINK

https://drive.google.com/file/d/1Y8OIaSGx2PLR0Br09UJ1ngo0kyFdKpRT/view

Features



Landing Page


![Screenshot 2024-06-29 123441](https://github.com/21wh1a1236/Freelancer-Application/assets/119932516/ba2a36af-52ae-4548-88c3-1be86c7e6f8d)

![Screenshot 2024-06-29 123533](https://github.com/21wh1a1236/Freelancer-Application/assets/119932516/ba528b65-729c-4ab2-84a6-87e3952c9c30)

![Screenshot 2024-06-29 123613](https://github.com/21wh1a1236/Freelancer-Application/assets/119932516/70cdaba1-55a0-40f3-9722-54541e50bccc)


Login page

![Screenshot 2024-06-29 123627](https://github.com/21wh1a1236/Freelancer-Application/assets/119932516/b80ef2b6-e7dc-4644-83ac-5011b2856701)


Register page

![Screenshot 2024-06-29 123653](https://github.com/21wh1a1236/Freelancer-Application/assets/119932516/70ad0c7d-fea0-4995-81e3-faf010122f36)






ADMIN

-Manage user registrations and logins

-View all projects and applications

-Ensure smooth operation of the platform

![Screenshot 2024-06-29 132814](https://github.com/21wh1a1236/Freelancer-Application/assets/119932516/187e92d8-8b5d-44da-99de-525ab157878f)

![Screenshot 2024-06-29 132820](https://github.com/21wh1a1236/Freelancer-Application/assets/119932516/50ede97e-4a19-4344-8826-52e7d748583a)

![Screenshot 2024-06-29 132834](https://github.com/21wh1a1236/Freelancer-Application/assets/119932516/0e4a0393-d9bc-4e32-852a-67fd4654d27a)

![Screenshot 2024-06-29 132846](https://github.com/21wh1a1236/Freelancer-Application/assets/119932516/01b1b4b0-7247-4bda-8ebd-5d37f2954ced)







FREELANCER

-Upload skills

-Bid on projects posted by clients

-Chat with clients to discuss project details

-Accomplish projects upon client acceptance

Freelancer page appearance

![Screenshot 2024-06-29 123729](https://github.com/21wh1a1236/Freelancer-Application/assets/119932516/79dda876-4763-4a40-be35-4c9f776122ff)

![Screenshot 2024-06-29 123744](https://github.com/21wh1a1236/Freelancer-Application/assets/119932516/baa57a4d-824d-45c6-b310-3b6ab1167c71)

![Screenshot 2024-06-29 131749](https://github.com/21wh1a1236/Freelancer-Application/assets/119932516/84efd8a3-e6ed-4e89-a3be-6e115a784173)

![Screenshot 2024-06-29 124035](https://github.com/21wh1a1236/Freelancer-Application/assets/119932516/254c0dee-85d8-44d0-853a-388ad6f9e170)

![Screenshot 2024-06-29 124041](https://github.com/21wh1a1236/Freelancer-Application/assets/119932516/df63f529-a368-415b-8b3c-ff3431d282ae)

![Screenshot 2024-06-29 131133](https://github.com/21wh1a1236/Freelancer-Application/assets/119932516/1a8a01ff-7116-46e5-93ba-0df545d6741e)

![Screenshot 2024-06-29 132610](https://github.com/21wh1a1236/Freelancer-Application/assets/119932516/8cc0cf0e-0487-4039-ba58-fdf687024d1c)






Client

-Post projects for freelancers to bid on

-Review proposals from freelancers

-Accept or reject proposals

-Chat with freelancers to finalize project details



![Screenshot 2024-06-29 132736](https://github.com/21wh1a1236/Freelancer-Application/assets/119932516/348d5ba3-2545-411a-b5d0-17d30742554b)


![Screenshot 2024-06-29 132747](https://github.com/21wh1a1236/Freelancer-Application/assets/119932516/63a914ca-00ca-4d21-a6df-7d9905d8edaa)


![Screenshot 2024-06-29 131332](https://github.com/21wh1a1236/Freelancer-Application/assets/119932516/e7b45a71-470b-4324-af8d-8ed0db23c630)


![Screenshot 2024-06-29 132610](https://github.com/21wh1a1236/Freelancer-Application/assets/119932516/c2f8b11f-8174-40a2-ba9d-be45b857619f)




Team Members

-M.Sree AKshitha (21wh1a1219)

-P.Deekshitha(21wh1a1236)

-M.Apoorva (21wh1a1212)

-M.Harshitha Reddy (21wh1a1216)




